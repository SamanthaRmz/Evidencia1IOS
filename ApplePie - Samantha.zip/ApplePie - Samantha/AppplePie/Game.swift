//
//  Game.swift
//  ApplePie
//
//  Created by Samantha Ramirez on 07/03/24.
//

import Foundation

struct Game {
    var word: String
    var incorrectMovesRemaining: Int
    
    var guessedLetters: [Character]
    
    mutating func playerGuessed(letter: Character) {
        guessedLetters.append(letter)
        
        if !word.contains(letter) {
            incorrectMovesRemaining -= 1
        }
    }
    
    var formatteWord: String {
        var guessWord = ""
        for letter in word {
            if guessedLetters.contains(letter) {
                guessWord += "\(letter)"
            } else {
                guessWord += "_"
            }
        }
        return guessWord
    }
}
